﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace ProtoBufServer
{
    public class NetworkController
    {

        //接收到客户端注册消息
        public static void ReceiveRegister(RequestRegister data, ClientSocket client)
        {
            if (client != null)
            {
                Console.WriteLine("注册用户:" + data.Account);
                Player player = new Player(data.Account, data.Password, data.Username);
                UnityGameServer.Instance.Players.Add(player);
                if (UnityGameServer.Instance.Save())
                {
                    PlayerInfo info = new PlayerInfo()
                    {
                        Id = player.id,
                        Account = player.account,
                        Username = player.username,
                        Passwrod = player.password
                    };

                    SendRegister(client, info, "");
                }
                else
                {
                    SendRegister(client, null, "注册失败");
                }
            }
        }

        //返回客户端注册消息
        public static void SendRegister(ClientSocket client,PlayerInfo info,string _error)
        {
            ResponseRegister response = new ResponseRegister() 
            {
                Proto = (int)CmdEnum.ResRegister,
                Error = _error,
                PlayerInfo = info
            };

            byte[] bytes = ProtobufTool.CreateData(response.Proto, response);
            client.socket.Send(bytes);

        }

        //接收到客户端登录消息
        public static void ReceiveLogin(RequestLogin data,ClientSocket client)
        {
            //记录用户名
            if (client != null)
            {
                Player player = UnityGameServer.Instance.GetPlayerByAccount(data.Account);
                if (player != null)
                {
                    if (player.password == data.Password)
                    {
                        SendLogin(client,player,"", "登陆成功");
                        Console.WriteLine("登录用户：UserName={0}", data.Account);
                    }
                    else
                    {
                        SendLogin(client,null,"密码不正确", "登陆失败");
                        Console.WriteLine("登录用户密码不正确：UserName={0}", data.Account);
                    }
                }
                else
                {
                    SendLogin(client,null, "账号不存在", "登陆失败");
                    Console.WriteLine("登录用户账号不存在：UserName={0}", data.Account);
                }
            }
        }

        //返回客户端登录消息
        public static void SendLogin(ClientSocket client,Player player,string error,string result)
        {
            ResponseLogin response = new ResponseLogin()
            {
                Proto = (int)CmdEnum.ResLogin,
                Error = error,
                Result = result
            };

            if (player != null)
            {
                response.Player = new PlayerInfo()
                {
                    Id = player.id,
                    Account = player.account,
                    Passwrod = player.password,
                    Username = player.username
                };
            }
            byte[] bytes = ProtobufTool.CreateData(response.Proto, response);
            client.socket.Send(bytes);
        }

        //接收客户端心跳消息
        public static void ReceiveAlive(ClientSocket client)
        {
            if (client != null)
            {
                client.SetTicks(DateTime.Now.Ticks);
                SendAlive(client);
            }
        }

        //返回客户端心跳消息
        public static void SendAlive(ClientSocket client)
        {
            ResponseAlive response = new ResponseAlive()
            {
                Proto = (int)CmdEnum.ResAlive
            };
            byte[] bytes = ProtobufTool.CreateData(response.Proto, response);
            client.socket.Send(bytes);
        }

        //接收客户端创建房间的消息
        public static void ReceiveCreateRoom(RequestCreateRoom req,ClientSocket m)
        {
            if (m != null)
            {
                RoomInfo info = RoomController.Instance.CreateRoom(m,req.PlayerId, req.RoomName, req.Password, req.CanWatch, req.PlayerNumber);
                if (info != null)
                {
                    SendCreateRoom(m, info.room, "");
                    Console.WriteLine("{0}创建房间{1}",req.PlayerId,req.RoomName);
                }
                else
                {
                    SendCreateRoom(m, null, "创建房间失败");
                    Console.WriteLine("{0}创建房间{1}失败", req.PlayerId, req.RoomName);
                }
            }
        }

        //返回客户端创建房间的消息
        public static void SendCreateRoom(ClientSocket client,GameRoomInfo info,string error)
        {
            ResponseCreateRoom response = new ResponseCreateRoom()
            {
                Proto = (int)CmdEnum.ResCreateRoom,
                Room = info,
                Error = error
            };
            byte[] bytes = ProtobufTool.CreateData(response.Proto, response);
            client.socket.Send(bytes);
        }


        //接收客户端获取房间列表的消息
        public static void ReceiveGetRooms(RequestGetRooms req,ClientSocket m)
        {
            if (m != null)
            {
                List<GameRoomInfo> infos = RoomController.Instance.GetRooms();
                SendGetRooms(m, infos);
                Console.WriteLine("{0}请求房间列表", m.socket.RemoteEndPoint.ToString());
            }
        }

        //返回客户端获取房间列表的消息
        public static void SendGetRooms(ClientSocket m,List<GameRoomInfo> infos)
        {
            ResponseGetRooms response = new ResponseGetRooms()
            {
                Proto = (int)CmdEnum.ResGetRooms,
            };
            response.Rooms.AddRange(infos);

            byte[] bytes = ProtobufTool.CreateData(response.Proto, response);
            m.socket.Send(bytes);
        }

        //接收客户端删除房间的消息
        public static void ReceiveDeleteRoom(RequestDeleteRoom req,ClientSocket m)
        { 
        }

        //返回客户端删除房间的消息
        public static void SendDeleteRoom()
        { 
        }
    }
}
