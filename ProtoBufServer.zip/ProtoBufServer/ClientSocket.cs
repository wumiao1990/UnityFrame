﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ProtoBufServer
{
    public class ClientSocket
    {
        public string userName;
        public string ip;
        public long ticks;
        public Socket socket;
        public Thread receiveThread;

        public ClientSocket(Socket mSocket)
        {
            if (mSocket != null)
            {
                ticks = DateTime.Now.Ticks;
                socket = mSocket;
                ip = mSocket.RemoteEndPoint.ToString();
                userName = "";
            }
        }

        public void SetUserName(string name)
        {
            userName = name;
        }

        public void SetTicks(long ticks)
        {
            this.ticks = ticks;
        }

        public void SetThread(Thread t)
        {
            receiveThread = t;
        }

        public bool CheckIsDisConnect(long sec)
        {
            long temp = DateTime.Now.Ticks - ticks;
            if ((temp / 10000000) > sec)
            {
                return false;
            }
            return true;
        }
    }
}
