﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

/// <summary>
/// 玩家基础信息的模型
/// </summary>

public class Player
{
    //玩家ID
    public string id { get; set; }
    //玩家账号
    public string account { get; set; }
    //玩家账号密码
    public string password { get; set; }
    //玩家用户名
    public string username { get; set; }
    //账号注册时间
    public DateTime createtime { get; set; }


    public Player() { }

    public Player(string _account, string _password, string _username)
    {
        id = CreatePlayerID();
        account = _account;
        password = _password;
        username = _username;
        createtime = DateTime.Now;
    }

    string CreatePlayerID()
    {
        return DateTime.Now.ToString("yyMMddhhmmff");
    }
}
