﻿using System.Data.Entity;
using System.Linq;

/// <summary>
/// 数据库EF交互控制器
/// </summary>
public class UnityGameServer : DbContext
{
    private static UnityGameServer m_self = null;
    public static UnityGameServer Instance
    {
        get
        {
            if (m_self == null)
            {
                m_self = new UnityGameServer();
            }
            return m_self;
        }
    }

    private UnityGameServer() :base("name=UnityGameServer") { }

    public DbSet<Player> Players { get; set; }


    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<Player>().ToTable("Players");
    }

    #region Player相关方法

    /// <summary>
    /// 根据玩家账号获取数据库中某条玩家的信息
    /// </summary>
    /// <param name="account">玩家账号</param>
    /// <returns></returns>
    public Player GetPlayerByAccount(string account)
    {
        Player p = (from player in Players where player.account == account select player).FirstOrDefault<Player>();
        return p;
    }

    /// <summary>
    /// 根据玩家ID获取数据库中某条玩家的信息
    /// </summary>
    /// <param name="id">玩家ID</param>
    /// <returns></returns>
    public Player GetPlayerByID(string id)
    {
        Player p = (from player in Players where player.id == id select player).FirstOrDefault<Player>();
        return p;
    }

    #endregion


    //保存数据变化
    public bool Save()
    {
        if (this.SaveChanges() > 0)
            return true;
        return false;
    }
}