﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ProtoBuf;

namespace ProtoBufServer
{
    public class RoomInfo
    {
        public GameRoomInfo room;
        public Dictionary<bool,List<ClientSocket>> players_in_room;

        public RoomInfo(ClientSocket client, string id, string name, string password, bool can_watch, int count)
        {
            players_in_room = new Dictionary<bool, List<ClientSocket>>();
            players_in_room.Add(true,new List<ClientSocket>(){client});

            room = new GameRoomInfo()
            {
                RoomId = id,
                RoomName = name,
                Password = password,
                CanWatch = can_watch,
                PlayerNumber = count
            };
        }
    }

    public class RoomController
    {
        private static RoomController m_self = null;
        public static RoomController Instance
        {
            get
            {
                if (m_self == null)
                {
                    m_self = new RoomController();
                }
                return m_self;
            }
        }

        private RoomController() { }

        //记录房间列表
        public Dictionary<string, RoomInfo> RoomList = new Dictionary<string, RoomInfo>();

        //创建一个房间并暂存
        public RoomInfo CreateRoom(ClientSocket client, string id, string name, string password, bool can_watch, int count)
        {
            RoomInfo info = new RoomInfo(client,id,name,password,can_watch,count);
            if (RoomList.ContainsKey(info.room.RoomId))
            {
                return null;
            }
            else
            {
                RoomList.Add(info.room.RoomId, info);
                return info;
            }
        }

        //进入一个房间
        public string JoinRoom(ClientSocket client, string id, string password)
        {
            if (RoomList.ContainsKey(id))
            {
                if (RoomList[id].players_in_room[true].Count < 2)
                {
                    if (RoomList[id].room.Password == password)
                    {
                        RoomList[id].players_in_room[true].Add(client);
                        return "";
                    }
                    else
                    {
                        return "房间密码不正确";
                    }
                }
                else
                {
                    return "房间人数已达上限";
                }
            }
            else
            {
                return "房间不存在";
            }
        }

        //旁观一个房间
        public string WatchRoom(ClientSocket client, string id, string password)
        {
            if (RoomList.ContainsKey(id))
            {
                if (RoomList[id].room.CanWatch)
                {
                    if (RoomList[id].players_in_room[false].Count < RoomList[id].room.PlayerNumber)
                    {
                        if (RoomList[id].room.Password == password)
                        {
                            RoomList[id].players_in_room[false].Add(client);
                            return "";
                        }
                        else
                        {
                            return "房间密码不正确";
                        }
                    }
                    else
                    {
                        return "房间人数已达上限";
                    }
                }
                else
                {
                    return "此房间禁止旁观";
                }
            }
            else
            {
                return "房间不存在";
            }
        }


        //退出一个房间
        public bool ExitRoom(ClientSocket client, string id)
        {
            try
            {
                RoomList[id].players_in_room[true].Remove(client);
                RoomList[id].players_in_room[false].Remove(client);
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        //获取房间列表
        public List<GameRoomInfo> GetRooms()
        {
            List<GameRoomInfo> result = new List<GameRoomInfo>();
            foreach (RoomInfo info in RoomList.Values)
            {
                result.Add(info.room);
            }
            return result;
        }
    }
}
